# THE KING es un juego que el objetivo es convertirse en Rey (llegar a 250 de dinero) sin morir en el camino

## JUGABILIDAD

1. **SALUD**:
Cada personaje tiene un valor único de salud la cúal no se puede aumentar, si llegas a 0 mueres

2. **DINERO**:
Todos los personajes empiezan con 0 y este dinero se puede usar para comprar equipamiento y para convertirte en rey

3. **PERSONAJES**:
Hay 4 a elegir (luchador, asesino, tanque y mago) cada uno tiene sus estadísticas propias. Todos los personajes están disponibles

4. **ESTADÍSTICAS**
Cada personaje tiene sus valores propios pero todos tienen las mismas(vitalidad, fuerza, agilidad, percepción mágica)

5. **ENTRENAMIENTO**
Es una de las opciones del Menú de acciones y te permite ganar puntos de experiencia

6. **PUNTOS DE EXPERIENCIA**
Sirven para mejorar tus estadísticas

7. **MISIONES**
Otra opción del Menú de acciones y te permite ganar dinero haciendo una misión, la contra es que necesitaras una serie de estadísticas a cierto nivel y que perderás salud

8. **TIENDA**
Es donde podrás gastar tu dinero en objetos que te modificarán tus estadisticas

## EJECUTAR

1. **TERMINAL**
Para ejecutarlo deberás primero descomprimir el directorio TheKing2_IvanBertolo.zip y navegar a la carpeta lib/Videojuego/ desde el terminal y ejecutar este comando:
java -jar Thekingv2.jar

2. **VISUAL STUDIO CODE**
Desde Visual deberás primero descomprimir el directorio TheKing2_IvanBertolo.zip y abrir desde visual la carpeta de Videojuego, seguidamente pulsas en src y en el archivo Videojuegov2.java que hay ya dentro del archivo darle a run.